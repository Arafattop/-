# АгроМаркет

Учебный проект по курсу «Fullstack-разработка».

- `agromarket-server/` — Express API (см. README внутри папки);
- `agromarket-react/` — React-клиент (Vite).

Запуск: сначала сервер (`cd agromarket-server && npm run dev`), затем клиент (`cd agromarket-react && npm run dev`).
